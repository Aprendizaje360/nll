<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">


<?php echo $__env->make('admin/partials/head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="<?php echo $__env->yieldContent("body-classes"); ?> <?php echo $__env->yieldContent('theme-skin', 'md-skin'); ?>">

  <!-- Wrapper-->
    <div id="wrapper">

        <?php if(Auth::guard('web_admin')->check()): ?>
        <!-- Navigation -->
          <?php echo $__env->make('admin.partials.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <!-- Page wraper -->
          <div id="page-wrapper" class="gray-bg">

              <!-- Page wrapper -->
              <?php echo $__env->make('admin.partials.topnavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- Main view  -->
              <?php echo $__env->yieldContent('content'); ?>

              <!-- Footer -->
              <?php echo $__env->make('admin.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          </div>
          <!-- End page wrapper-->
        <?php else: ?>

          <?php echo $__env->yieldContent('content'); ?>

        <?php endif; ?>
    </div>
    <!-- End wrapper-->



<?php $__env->startSection('footer_scripts'); ?>
    <script src="<?php echo e(asset('admin/vendor/js/jquery-3.1.1.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin/vendor/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin/vendor/js/inspinia.min.js')); ?>" type="text/javascript"></script>


    
<?php echo $__env->yieldSection(); ?>

</body>
</html>
