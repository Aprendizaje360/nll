<style>
    
</style>

<div>
    <div style="text-align: right">
        <table width="100%">
            <tr>
                <td width="50%" valign="middle" align="left">
                    <img src="{{ asset('neuro.jpg') }}" width="140px">
                </td>
                <td width="50%" valign="middle" align="right">
                    <img src="{{ asset('logocentrum.png') }}" width="140px">
                </td>
            </tr>
        </table>
    </div>

    <div class="bg-blue">
        <h1>REPORTE DE PARTICIPACIÓN EN EL NEUROLEADERSHIPLAB</h1>
        <br>
        <h2>{{ $user->name }} {{ $user->lastName }}</h2>
        <h2>{{ $date }}</h2>
    </div>

    <div class="border-blue">
       
    </div>
</div>
