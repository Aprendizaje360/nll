<nav>
	<div>Elige tu prueba</div>
	<div>
		<ul>
			<li>
				<a href="mailto:support@muse.com">
					<i class="fa fa-envelope" aria-hidden="true"></i>
					Mandar mensaje
				</a>
			</li>
			<li>
				<a href="{{route('enterprise.logout')}}">
					<i class="fa fa-sign-out" aria-hidden="true"></i>
					Cerrar sesión
				</a>
			</li>
		</ul>
	</div>
</nav>
