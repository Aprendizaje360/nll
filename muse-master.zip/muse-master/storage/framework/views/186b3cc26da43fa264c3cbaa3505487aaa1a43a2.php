<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <meta name="theme-color" content="<?php echo $__env->yieldContent('theme_color', '#000000'); ?>" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo $__env->yieldContent('title', 'Athelas Admin Theme'); ?> </title>

    
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/css/bootstrap.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('admin/font-awesome/css/font-awesome.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>" />
    <?php echo $__env->yieldSection(); ?>

    <?php $__env->startSection('head_scripts'); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->make('common/partials/favicons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>