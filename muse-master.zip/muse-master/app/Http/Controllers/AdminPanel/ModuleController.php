<?php

namespace App\Http\Controllers\AdminPanel;

use Illuminate\Http\Request;

class ModuleController extends Controller
{
    //
}
