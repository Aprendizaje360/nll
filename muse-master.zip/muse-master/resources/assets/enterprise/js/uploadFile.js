document.getElementById("excel").onchange = function() {
    document.getElementById("excel-form").submit();
};